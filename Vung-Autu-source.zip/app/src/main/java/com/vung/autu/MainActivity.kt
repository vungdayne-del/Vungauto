package com.vung.autu

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("vung_autu", MODE_PRIVATE) }
    private lateinit var gemini: EditText
    private lateinit var pageId: EditText
    private lateinit var token: EditText
    private lateinit var count: EditText
    private lateinit var topic: EditText
    private lateinit var post: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(20, 75, 135)
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
            setBackgroundColor(Color.rgb(246, 248, 251))
        }
        scroll.addView(root)
        setContentView(scroll)
        root.addView(label("Vung Autu", 27f, true))
        root.addView(label("Cài đặt AI và Facebook Page", 16f, false))
        gemini = addField(root, "Gemini API Key", "Dán Gemini API key", true)
        pageId = addField(root, "Facebook Page ID", "Nhập Page ID", false)
        token = addField(root, "Facebook Page Access Token", "Dán Page Access Token", true)
        count = addField(root, "Số bài mỗi ngày (mặc định 10)", "10", false).apply { inputType = InputType.TYPE_CLASS_NUMBER }
        topic = addField(root, "Chủ đề", "Để trống để AI tự chọn", false)
        post = addField(root, "Nội dung bài viết", "Nội dung tạo bởi Gemini sẽ hiện ở đây", false).apply { minLines = 5; gravity = android.view.Gravity.TOP }
        status = label("Trạng thái: Sẵn sàng", 14f, false)
        root.addView(button("Lưu cài đặt") { save(); setStatus("Đã lưu trên điện thoại.") })
        root.addView(button("Tạo nội dung bằng Gemini") {
            save()
            val key = gemini.text.toString().trim()
            if (key.isBlank()) setStatus("Hãy nhập Gemini API Key trước.") else generate(key, topic.text.toString().trim())
        })
        root.addView(button("Đăng bài văn bản lên Facebook Page") {
            save()
            val id = pageId.text.toString().trim(); val access = token.text.toString().trim(); val text = post.text.toString().trim()
            if (id.isBlank() || access.isBlank() || text.isBlank()) setStatus("Cần Page ID, Page Token và nội dung bài viết.") else publish(id, access, text)
        })
        root.addView(status)
        root.addView(label("Lưu ý: bản khởi tạo này tạo nội dung bằng Gemini và đăng bài văn bản khi bạn nhấn nút. Tự động đăng theo lịch và tạo ảnh chưa được triển khai.", 13f, false))
        load()
    }

    private fun addField(root: LinearLayout, title: String, hintText: String, secret: Boolean): EditText {
        root.addView(label(title, 14f, true))
        val edit = EditText(this).apply {
            hint = hintText; textSize = 15f; setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(Color.WHITE)
            if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        root.addView(edit, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        return edit
    }
    private fun label(text: String, size: Float, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(Color.rgb(40, 50, 65)); setPadding(0, dp(8), 0, dp(5))
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
    }
    private fun button(text: String, action: () -> Unit) = Button(this).apply { this.text = text; isAllCaps = false; setOnClickListener { action() } }
    private fun setStatus(text: String) { runOnUiThread { status.text = "Trạng thái: $text" } }
    private fun save() {
        prefs.edit().putString("gemini", gemini.text.toString().trim()).putString("page_id", pageId.text.toString().trim())
            .putString("page_token", token.text.toString().trim()).putString("count", count.text.toString().trim().ifBlank { "10" })
            .putString("topic", topic.text.toString().trim()).apply()
    }
    private fun load() {
        gemini.setText(prefs.getString("gemini", "")); pageId.setText(prefs.getString("page_id", ""))
        token.setText(prefs.getString("page_token", "")); count.setText(prefs.getString("count", "10")); topic.setText(prefs.getString("topic", ""))
    }
    private fun generate(key: String, topicText: String) {
        setStatus("Đang yêu cầu Gemini tạo bài…")
        thread {
            var conn: HttpURLConnection? = null
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$key")
                conn = (url.openConnection() as HttpURLConnection).apply { requestMethod = "POST"; connectTimeout = 20000; readTimeout = 30000; doOutput = true; setRequestProperty("Content-Type", "application/json") }
                val prompt = if (topicText.isBlank()) "Tự chọn chủ đề phù hợp và viết một bài đăng Facebook tiếng Việt hấp dẫn, tự nhiên, ngắn gọn, có lời mời tương tác." else "Viết bài đăng Facebook tiếng Việt hấp dẫn về chủ đề: $topicText."
                val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt))))).toString()
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val response = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code !in 200..299) throw Exception("Gemini HTTP $code: ${response.take(250)}")
                val text = JSONObject(response).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                runOnUiThread { post.setText(text); status.text = "Trạng thái: Đã tạo nội dung." }
            } catch (e: Exception) { setStatus("Lỗi Gemini: ${e.message}") } finally { conn?.disconnect() }
        }
    }
    private fun publish(id: String, accessToken: String, message: String) {
        setStatus("Đang đăng lên Facebook…")
        thread {
            var conn: HttpURLConnection? = null
            try {
                conn = (URL("https://graph.facebook.com/v23.0/$id/feed").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 20000; readTimeout = 30000; doOutput = true
                    setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                }
                val payload = "message=${java.net.URLEncoder.encode(message, "UTF-8")}&access_token=${java.net.URLEncoder.encode(accessToken, "UTF-8")}" 
                conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val response = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code !in 200..299) throw Exception("Facebook HTTP $code: ${response.take(250)}")
                setStatus("Đăng bài thành công.")
            } catch (e: Exception) { setStatus("Lỗi Facebook: ${e.message}. Kiểm tra Page ID, token và quyền đăng.") } finally { conn?.disconnect() }
        }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
