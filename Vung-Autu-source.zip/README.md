# Vung Autu

Android starter app with in-app fields for Gemini API Key, Facebook Page ID, and Facebook Page Access Token. Saves settings locally, generates Vietnamese Facebook post text with Gemini, and offers manual text posting to a Facebook Page. Daily post count setting defaults to 10.

Limitations: scheduled auto-posting and image generation/upload are not implemented. Facebook Page permissions, token validity, and Meta platform policies apply. Credentials are stored in local app preferences; do not publish or share an installation containing real credentials. If the Gemini model is unavailable to your project, update the model name in MainActivity.kt.

GitHub Actions workflow: .github/workflows/build.yml
